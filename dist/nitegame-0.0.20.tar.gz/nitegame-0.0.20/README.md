Nitegame Engine

A game engine built on Pygame & ModernGL meant to simplify common game systems, and the process of developing, primarily, 2D games.